# Cafe Kap

Website for Cafe Kap. Guests can see the menu, order and pay for drinks and
snacks to their table or as takeaway, and book a table. Staff log in to see
incoming orders and bookings and mark their status.

The site is in Danish.

## Pages

| URL            | What it is                                                     |
| -------------- | -------------------------------------------------------------- |
| `/`            | Landing page                                                   |
| `/menu`        | Full menu with add-to-cart                                     |
| `/kasse`       | Checkout: table/takeaway, notes, payment                       |
| `/bestil-bord` | Table booking                                                  |
| `/login`       | Staff login (demo: `personale@cafekap.dk` / `kaffe123`)        |
| `/personale`   | Staff dashboard: order board and bookings with status controls |

## Tech

TanStack Start (React 19), Tailwind CSS 4, shadcn/ui components, deployed on
Netlify. Photos are served through the Netlify Image CDN.

## Run locally

```bash
pnpm install
netlify dev
```

## Current state and roadmap

Payments, orders, bookings and the staff login are currently demo versions:
data is kept in the browser (localStorage) via `src/lib/fixtures.ts`, and the
payment step does not charge anything. The next steps are a database for
orders and bookings, Netlify Identity for staff, Stripe payments and a live
order status page for guests. See [PLAN.md](PLAN.md).
