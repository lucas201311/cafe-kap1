# Cafe Kap – roadmap

Cafe Kap is a café website where guests can browse the menu, order and pay for
drinks and snacks, and book a table, and where staff log in to follow orders
and bookings and update their status.

## Milestone 1 – Product surface ✅

- Landing page with hero, house favourites and booking teaser.
- Menu page with the full Cafe Kap menu (Med kaffe, Uden kaffe, Snacks) and add-to-cart.
- Cart drawer and checkout page (`/kasse`) with name, table/takeaway, notes and a demo payment (MobilePay / card).
- Table booking page (`/bestil-bord`) with guests, date, time slots and contact details.
- Staff login (`/login`) and staff dashboard (`/personale`) with an order board (Ny → I gang → Klar → Leveret) and a bookings table with status.
- All data lives in `src/lib/fixtures.ts` (menu, seeded orders/bookings, localStorage demo store, demo staff login).

## Milestone 2 – Database for orders and bookings

- Netlify Database (Postgres + Drizzle) with `orders`, `order_lines` and `bookings` tables in `db/schema.ts`.
- Server functions to create orders/bookings and list/update them, replacing the localStorage functions in `fixtures.ts` one by one (same signatures).
- Keep the menu in code for now, or move it to a `menu_items` table if staff should edit it (see milestone 6).

## Milestone 3 – Real staff login

- Netlify Identity with a `staff` role; invite-only signups.
- Protect `/personale` and every staff server function by role, remove the demo credentials.

## Milestone 4 – Real payments

- Stripe Checkout (supports cards and MobilePay in Denmark) — needs the café's Stripe account.
- Create the order as "unpaid", mark it paid from the Stripe webhook, and only then show it on the staff board.

## Milestone 5 – Live status for guests

- Order confirmation page (`/ordre/$id`) that shows the current status to the guest and refreshes automatically.
- Optional booking confirmation email/SMS when staff confirm a booking.

## Milestone 6 – Nice to have

- Staff can edit menu items, prices and mark items as sold out.
- Table availability (max guests per time slot) so bookings can't overbook.
- Opening hours and address editable from the dashboard.
