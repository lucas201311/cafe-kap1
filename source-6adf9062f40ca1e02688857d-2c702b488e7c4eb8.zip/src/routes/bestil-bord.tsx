import { createFileRoute } from '@tanstack/react-router'
import { CalendarCheck, Minus, Plus } from 'lucide-react'
import * as React from 'react'

import { PageShell } from '@/components/site-layout'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { bookingTimes, createBooking, openingHours, type Booking } from '@/lib/fixtures'

export const Route = createFileRoute('/bestil-bord')({
  head: () => ({ meta: [{ title: 'Book bord – Cafe Kap' }] }),
  component: BookingPage,
})

const todayIso = () => new Date().toISOString().slice(0, 10)

function BookingPage() {
  const [guests, setGuests] = React.useState(2)
  const [date, setDate] = React.useState('')
  const [time, setTime] = React.useState('')
  const [form, setForm] = React.useState({ name: '', phone: '', email: '', note: '' })
  const [errors, setErrors] = React.useState<Record<string, string>>({})
  const [booking, setBooking] = React.useState<Booking | null>(null)
  const [minDate, setMinDate] = React.useState('')

  React.useEffect(() => {
    setMinDate(todayIso())
    setDate(todayIso())
  }, [])

  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }))

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const next: Record<string, string> = {}
    if (!date) next.date = 'Vælg en dato.'
    if (!time) next.time = 'Vælg et tidspunkt.'
    if (!form.name.trim()) next.name = 'Skriv dit navn.'
    if (!/^[\d +]{8,}$/.test(form.phone.trim())) next.phone = 'Skriv et gyldigt telefonnummer.'
    if (form.email && !/^\S+@\S+\.\S+$/.test(form.email)) next.email = 'E-mailen ser forkert ud.'
    setErrors(next)
    if (Object.keys(next).length) return
    setBooking(
      createBooking({
        guests,
        date,
        time,
        name: form.name.trim(),
        phone: form.phone.trim(),
        email: form.email.trim(),
        note: form.note.trim(),
      }),
    )
  }

  return (
    <PageShell>
      <div className="mx-auto grid max-w-content gap-12 px-4 py-14 sm:px-6 lg:grid-cols-[1fr_24rem]">
        <div>
          <h1 className="text-5xl font-semibold">Book et bord</h1>
          <p className="mt-3 max-w-md text-muted-foreground">
            Vælg dato, tid og antal gæster. Vi bekræfter din booking hurtigst muligt.
          </p>

          {booking ? (
            <div className="mt-10 rounded-lg border bg-card p-8">
              <CalendarCheck className="size-10 text-primary" aria-hidden />
              <h2 className="mt-4 text-3xl font-semibold">Tak, {booking.name}!</h2>
              <p className="mt-2 text-muted-foreground">
                Vi har modtaget din booking <strong>{booking.id}</strong> til{' '}
                {booking.guests} {booking.guests === 1 ? 'person' : 'personer'} den{' '}
                {new Date(booking.date).toLocaleDateString('da-DK', { weekday: 'long', day: 'numeric', month: 'long' })}{' '}
                kl. {booking.time}. Du hører fra os, når den er bekræftet.
              </p>
              <Button variant="outline" className="mt-6" onClick={() => { setBooking(null); setTime('') }}>
                Lav en ny booking
              </Button>
            </div>
          ) : (
            <form onSubmit={submit} noValidate className="mt-10 space-y-8">
              <div className="grid gap-6 sm:grid-cols-2">
                <div className="grid gap-2">
                  <Label>Antal gæster</Label>
                  <div className="flex h-9 items-center justify-between rounded-md border px-1">
                    <Button type="button" variant="ghost" size="icon-sm" aria-label="Færre gæster" onClick={() => setGuests((g) => Math.max(1, g - 1))}>
                      <Minus />
                    </Button>
                    <span className="tabular-nums" aria-live="polite">{guests} {guests === 1 ? 'person' : 'personer'}</span>
                    <Button type="button" variant="ghost" size="icon-sm" aria-label="Flere gæster" onClick={() => setGuests((g) => Math.min(8, g + 1))}>
                      <Plus />
                    </Button>
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="date">Dato</Label>
                  <Input id="date" type="date" min={minDate} value={date} onChange={(e) => setDate(e.target.value)} aria-invalid={Boolean(errors.date)} />
                  {errors.date && <p className="text-sm text-destructive">{errors.date}</p>}
                </div>
              </div>

              <div>
                <p className="mb-3 text-sm font-medium">Tidspunkt</p>
                <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Tidspunkt">
                  {bookingTimes.map((t) => (
                    <button
                      key={t}
                      type="button"
                      role="radio"
                      aria-checked={time === t}
                      onClick={() => setTime(t)}
                      className="rounded-md border px-3 py-1.5 text-sm tabular-nums transition-colors hover:bg-muted aria-checked:border-primary aria-checked:bg-primary aria-checked:text-primary-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50 outline-none motion-reduce:transition-none"
                    >
                      {t}
                    </button>
                  ))}
                </div>
                {errors.time && <p className="mt-2 text-sm text-destructive">{errors.time}</p>}
              </div>

              <div className="grid gap-6 sm:grid-cols-2">
                <div className="grid gap-2">
                  <Label htmlFor="name">Navn</Label>
                  <Input id="name" value={form.name} onChange={set('name')} autoComplete="name" aria-invalid={Boolean(errors.name)} />
                  {errors.name && <p className="text-sm text-destructive">{errors.name}</p>}
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="phone">Telefon</Label>
                  <Input id="phone" type="tel" value={form.phone} onChange={set('phone')} autoComplete="tel" aria-invalid={Boolean(errors.phone)} />
                  {errors.phone && <p className="text-sm text-destructive">{errors.phone}</p>}
                </div>
                <div className="grid gap-2 sm:col-span-2">
                  <Label htmlFor="email">E-mail (valgfrit)</Label>
                  <Input id="email" type="email" value={form.email} onChange={set('email')} autoComplete="email" aria-invalid={Boolean(errors.email)} />
                  {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
                </div>
                <div className="grid gap-2 sm:col-span-2">
                  <Label htmlFor="note">Bemærkninger (valgfrit)</Label>
                  <Textarea id="note" value={form.note} onChange={set('note')} placeholder="Fødselsdag, barnestol, allergier…" />
                </div>
              </div>

              <Button type="submit" size="lg">Send booking</Button>
            </form>
          )}
        </div>

        <aside className="space-y-6">
          <img
            src="/.netlify/images?url=/img/tables.png&w=800&fm=webp&q=75"
            alt="Dækkede borde i Cafe Kap"
            className="aspect-[4/3] w-full rounded-lg object-cover"
          />
          <div className="rounded-lg bg-secondary/50 p-6">
            <h2 className="text-2xl font-semibold">Åbningstider</h2>
            <ul className="mt-3 space-y-1 text-sm">
              {openingHours.map((o) => (
                <li key={o.days} className="flex justify-between">
                  <span>{o.days}</span>
                  <span className="tabular-nums">{o.hours}</span>
                </li>
              ))}
            </ul>
            <p className="mt-4 text-sm text-muted-foreground">
              Selskaber over 8 personer: skriv til hej@cafekap.dk.
            </p>
          </div>
        </aside>
      </div>
    </PageShell>
  )
}
