import { Link, createFileRoute, useNavigate } from '@tanstack/react-router'
import { ArrowRight, CalendarDays, Coffee, LogOut, RefreshCw, Users } from 'lucide-react'
import * as React from 'react'
import { toast } from 'sonner'

import { Logo } from '@/components/site-layout'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  bookingStatuses,
  currentStaff,
  formatPrice,
  listBookings,
  listOrders,
  orderStatuses,
  staffSignOut,
  updateBookingStatus,
  updateOrderStatus,
  type Booking,
  type Order,
  type OrderStatus,
} from '@/lib/fixtures'

export const Route = createFileRoute('/personale')({
  head: () => ({ meta: [{ title: 'Personale – Cafe Kap' }] }),
  component: StaffPage,
})

const orderTone: Record<OrderStatus, string> = {
  ny: 'bg-amber-100 text-amber-900 border-amber-200',
  'i-gang': 'bg-sky-100 text-sky-900 border-sky-200',
  klar: 'bg-emerald-100 text-emerald-900 border-emerald-200',
  leveret: 'bg-muted text-muted-foreground border-border',
}

const bookingTone: Record<Booking['status'], string> = {
  afventer: 'bg-amber-100 text-amber-900 border-amber-200',
  bekraeftet: 'bg-sky-100 text-sky-900 border-sky-200',
  ankommet: 'bg-emerald-100 text-emerald-900 border-emerald-200',
  aflyst: 'bg-muted text-muted-foreground border-border line-through',
}

const nextStatus: Partial<Record<OrderStatus, OrderStatus>> = {
  ny: 'i-gang',
  'i-gang': 'klar',
  klar: 'leveret',
}

const labelFor = (s: OrderStatus) => orderStatuses.find((o) => o.id === s)!.label

function timeAgo(iso: string) {
  const min = Math.round((Date.now() - new Date(iso).getTime()) / 60_000)
  if (min < 1) return 'lige nu'
  if (min < 60) return `${min} min siden`
  return new Date(iso).toLocaleTimeString('da-DK', { hour: '2-digit', minute: '2-digit' })
}

function StaffPage() {
  const navigate = useNavigate()
  const [staff, setStaff] = React.useState<string | null>(null)
  const [orders, setOrders] = React.useState<Order[] | null>(null)
  const [bookings, setBookings] = React.useState<Booking[] | null>(null)

  const refresh = React.useCallback(() => {
    setOrders(listOrders())
    setBookings(listBookings())
  }, [])

  React.useEffect(() => {
    const who = currentStaff()
    if (!who) {
      navigate({ to: '/login' })
      return
    }
    setStaff(who)
    refresh()
    const onStorage = () => refresh()
    window.addEventListener('storage', onStorage)
    const timer = window.setInterval(refresh, 10_000)
    return () => {
      window.removeEventListener('storage', onStorage)
      window.clearInterval(timer)
    }
  }, [navigate, refresh])

  function setOrderStatus(id: string, status: OrderStatus) {
    setOrders(updateOrderStatus(id, status))
    toast.success(`Ordre #${id} er nu: ${labelFor(status)}`)
  }

  function setBookingStatus(id: string, status: Booking['status']) {
    setBookings(updateBookingStatus(id, status))
  }

  const today = new Date().toISOString().slice(0, 10)
  const stats = orders && bookings
    ? [
        { label: 'Nye ordrer', value: orders.filter((o) => o.status === 'ny').length, icon: Coffee },
        { label: 'I gang', value: orders.filter((o) => o.status === 'i-gang').length, icon: RefreshCw },
        { label: 'Omsætning i dag', value: formatPrice(orders.filter((o) => o.createdAt.slice(0, 10) === today).reduce((s, o) => s + o.total, 0)), icon: ArrowRight },
        { label: 'Bookinger i dag', value: bookings.filter((b) => b.date === today && b.status !== 'aflyst').length, icon: CalendarDays },
      ]
    : null

  return (
    <div className="min-h-screen bg-muted/40">
      <header className="espresso-texture text-primary-foreground">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-4">
            <Logo />
            <Badge variant="secondary">Personale</Badge>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <span className="hidden text-primary-foreground/70 sm:inline">{staff}</span>
            <Button asChild variant="ghost" size="sm" className="hover:bg-primary-foreground/10 hover:text-primary-foreground">
              <Link to="/">Til hjemmesiden</Link>
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                staffSignOut()
                navigate({ to: '/login' })
              }}
            >
              <LogOut /> Log ud
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-4xl font-semibold">Overblik</h1>
            <p className="text-muted-foreground">
              {new Date().toLocaleDateString('da-DK', { weekday: 'long', day: 'numeric', month: 'long' })}
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={refresh}>
            <RefreshCw /> Opdatér
          </Button>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats
            ? stats.map(({ label, value, icon: Icon }) => (
                <div key={label} className="rounded-lg border bg-card p-5">
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    {label} <Icon className="size-4" aria-hidden />
                  </div>
                  <p className="mt-2 font-display text-4xl font-semibold tabular-nums">{value}</p>
                </div>
              ))
            : Array.from({ length: 4 }, (_, i) => <Skeleton key={i} className="h-[104px] rounded-lg" />)}
        </div>

        <Tabs defaultValue="ordrer" className="mt-8">
          <TabsList>
            <TabsTrigger value="ordrer">
              <Coffee /> Bestillinger
            </TabsTrigger>
            <TabsTrigger value="bookinger">
              <Users /> Bordbookinger
            </TabsTrigger>
          </TabsList>

          <TabsContent value="ordrer" className="mt-4">
            {orders ? (
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                {orderStatuses.map((col) => {
                  const list = orders.filter((o) => o.status === col.id)
                  return (
                    <section key={col.id} className="rounded-lg bg-muted/70 p-3" aria-label={col.label}>
                      <h2 className="mb-3 flex items-center justify-between px-1 font-sans text-sm font-semibold uppercase tracking-wide">
                        {col.label}
                        <span className={`rounded-full border px-2 text-xs ${orderTone[col.id]}`}>{list.length}</span>
                      </h2>
                      <div className="space-y-3">
                        {list.length === 0 && (
                          <p className="rounded-md border border-dashed px-3 py-6 text-center text-sm text-muted-foreground">
                            Ingen ordrer
                          </p>
                        )}
                        {list.map((o) => (
                          <OrderCard key={o.id} order={o} onStatus={setOrderStatus} />
                        ))}
                      </div>
                    </section>
                  )
                })}
              </div>
            ) : (
              <Skeleton className="h-80 rounded-lg" />
            )}
          </TabsContent>

          <TabsContent value="bookinger" className="mt-4">
            {bookings ? (
              <div className="overflow-x-auto rounded-lg border bg-card">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Booking</TableHead>
                      <TableHead>Dato & tid</TableHead>
                      <TableHead>Gæst</TableHead>
                      <TableHead>Antal</TableHead>
                      <TableHead>Note</TableHead>
                      <TableHead className="w-40">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[...bookings]
                      .sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`))
                      .map((b) => (
                        <TableRow key={b.id}>
                          <TableCell className="font-medium">{b.id}</TableCell>
                          <TableCell className="tabular-nums">
                            {new Date(b.date).toLocaleDateString('da-DK', { day: 'numeric', month: 'short' })} · {b.time}
                          </TableCell>
                          <TableCell>
                            <div>{b.name}</div>
                            <div className="text-xs text-muted-foreground">{b.phone}</div>
                          </TableCell>
                          <TableCell>{b.guests}</TableCell>
                          <TableCell className="max-w-48 truncate text-muted-foreground">{b.note || '—'}</TableCell>
                          <TableCell>
                            <Select value={b.status} onValueChange={(v) => setBookingStatus(b.id, v as Booking['status'])}>
                              <SelectTrigger size="sm" className={`w-36 ${bookingTone[b.status]}`} aria-label={`Status for ${b.id}`}>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {bookingStatuses.map((s) => (
                                  <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <Skeleton className="h-60 rounded-lg" />
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

function OrderCard({ order, onStatus }: { order: Order; onStatus: (id: string, s: OrderStatus) => void }) {
  const next = nextStatus[order.status]
  return (
    <article className="rounded-md border bg-card p-4 shadow-xs">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-display text-xl font-semibold">#{order.id}</p>
          <p className="text-sm">
            {order.customerName} · {order.table === 'Takeaway' ? 'Takeaway' : `Bord ${order.table}`}
          </p>
        </div>
        <span className="text-xs text-muted-foreground">{timeAgo(order.createdAt)}</span>
      </div>
      <ul className="mt-3 space-y-0.5 text-sm">
        {order.lines.map((l) => (
          <li key={l.itemId}>
            <span className="font-medium tabular-nums">{l.quantity}×</span> {l.name}
          </li>
        ))}
      </ul>
      {order.note && <p className="mt-2 rounded bg-amber-50 px-2 py-1 text-xs text-amber-900">“{order.note}”</p>}
      <div className="mt-3 flex items-center justify-between text-sm">
        <span className="font-medium tabular-nums">{formatPrice(order.total)}</span>
        <Badge variant="outline" className="border-emerald-200 bg-emerald-50 text-emerald-800">
          Betalt · {order.paymentMethod === 'kort' ? 'Kort' : 'MobilePay'}
        </Badge>
      </div>
      <div className="mt-3 flex gap-2">
        <Select value={order.status} onValueChange={(v) => onStatus(order.id, v as OrderStatus)}>
          <SelectTrigger size="sm" className="flex-1" aria-label={`Status for ordre ${order.id}`}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {orderStatuses.map((s) => (
              <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {next && (
          <Button size="sm" onClick={() => onStatus(order.id, next)}>
            {labelFor(next)} <ArrowRight />
          </Button>
        )}
      </div>
    </article>
  )
}
