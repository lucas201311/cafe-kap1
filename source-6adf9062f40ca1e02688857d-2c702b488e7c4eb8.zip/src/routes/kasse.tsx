import { Link, createFileRoute } from '@tanstack/react-router'
import { CheckCircle2, CreditCard, Loader2, Lock, Smartphone } from 'lucide-react'
import * as React from 'react'

import { PageShell } from '@/components/site-layout'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { useCart } from '@/lib/cart'
import { createOrder, formatPrice, type Order } from '@/lib/fixtures'

export const Route = createFileRoute('/kasse')({
  head: () => ({ meta: [{ title: 'Betaling – Cafe Kap' }] }),
  component: CheckoutPage,
})

const tables = ['Takeaway', ...Array.from({ length: 10 }, (_, i) => String(i + 1))]

function CheckoutPage() {
  const cart = useCart()
  const [name, setName] = React.useState('')
  const [table, setTable] = React.useState('')
  const [note, setNote] = React.useState('')
  const [method, setMethod] = React.useState<Order['paymentMethod']>('mobilepay')
  const [paying, setPaying] = React.useState(false)
  const [errors, setErrors] = React.useState<Record<string, string>>({})
  const [order, setOrder] = React.useState<Order | null>(null)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    const next: Record<string, string> = {}
    if (!name.trim()) next.name = 'Skriv dit navn, så vi kan råbe dig op.'
    if (!table) next.table = 'Vælg et bord eller takeaway.'
    setErrors(next)
    if (Object.keys(next).length) return

    setPaying(true)
    await new Promise((r) => setTimeout(r, 1400))
    const created = createOrder({
      customerName: name.trim(),
      table,
      note: note.trim(),
      paymentMethod: method,
      lines: cart.lines.map((l) => ({
        itemId: l.item.id,
        name: l.item.name,
        price: l.item.price,
        quantity: l.quantity,
      })),
    })
    cart.clear()
    setPaying(false)
    setOrder(created)
  }

  if (order) {
    return (
      <PageShell>
        <div className="mx-auto max-w-reading px-4 py-20 text-center sm:px-6">
          <CheckCircle2 className="mx-auto size-14 text-primary" aria-hidden />
          <h1 className="mt-4 text-5xl font-semibold">Tak, {order.customerName}!</h1>
          <p className="mt-3 text-muted-foreground">
            Din betaling på {formatPrice(order.total)} er gennemført, og baristaen er
            gået i gang.
          </p>
          <Card className="mt-10 text-left">
            <CardHeader>
              <CardTitle className="flex items-baseline justify-between">
                <span className="font-display text-2xl">Ordre #{order.id}</span>
                <span className="text-sm font-normal text-muted-foreground">
                  {order.table === 'Takeaway' ? 'Takeaway' : `Bord ${order.table}`}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-1">
                {order.lines.map((l) => (
                  <li key={l.itemId} className="flex justify-between">
                    <span>
                      {l.quantity} × {l.name}
                    </span>
                    <span className="tabular-nums">{formatPrice(l.price * l.quantity)}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
          <Button asChild variant="outline" className="mt-8">
            <Link to="/menu">Bestil mere</Link>
          </Button>
        </div>
      </PageShell>
    )
  }

  return (
    <PageShell>
      <div className="mx-auto max-w-content px-4 py-14 sm:px-6">
        <h1 className="text-5xl font-semibold">Bestil & betal</h1>
        {cart.lines.length === 0 ? (
          <div className="mt-10 rounded-lg border border-dashed p-12 text-center">
            <p className="text-muted-foreground">Din kurv er tom.</p>
            <Button asChild className="mt-4">
              <Link to="/menu">Gå til menuen</Link>
            </Button>
          </div>
        ) : (
          <form onSubmit={submit} className="mt-10 grid gap-10 lg:grid-cols-[1fr_22rem]" noValidate>
            <div className="space-y-8">
              <fieldset className="grid gap-5 sm:grid-cols-2">
                <legend className="mb-4 font-display text-2xl font-semibold">Hvem bestiller?</legend>
                <div className="grid gap-2">
                  <Label htmlFor="name">Navn</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    aria-invalid={Boolean(errors.name)}
                    autoComplete="given-name"
                  />
                  {errors.name && <p className="text-sm text-destructive">{errors.name}</p>}
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="table">Bord</Label>
                  <Select value={table} onValueChange={setTable}>
                    <SelectTrigger id="table" className="w-full" aria-invalid={Boolean(errors.table)}>
                      <SelectValue placeholder="Vælg bord" />
                    </SelectTrigger>
                    <SelectContent>
                      {tables.map((t) => (
                        <SelectItem key={t} value={t}>
                          {t === 'Takeaway' ? 'Takeaway' : `Bord ${t}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.table && <p className="text-sm text-destructive">{errors.table}</p>}
                </div>
                <div className="grid gap-2 sm:col-span-2">
                  <Label htmlFor="note">Ønsker (valgfrit)</Label>
                  <Textarea
                    id="note"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="F.eks. havremælk, ekstra varm…"
                  />
                </div>
              </fieldset>

              <fieldset>
                <legend className="mb-4 font-display text-2xl font-semibold">Betaling</legend>
                <RadioGroup
                  value={method}
                  onValueChange={(v) => setMethod(v as Order['paymentMethod'])}
                  className="grid gap-3 sm:grid-cols-2"
                >
                  {[
                    { id: 'mobilepay', label: 'MobilePay', icon: Smartphone },
                    { id: 'kort', label: 'Betalingskort', icon: CreditCard },
                  ].map(({ id, label, icon: Icon }) => (
                    <Label
                      key={id}
                      htmlFor={`pay-${id}`}
                      className="flex cursor-pointer items-center gap-3 rounded-lg border p-4 has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-muted"
                    >
                      <RadioGroupItem id={`pay-${id}`} value={id} />
                      <Icon className="size-5" aria-hidden />
                      {label}
                    </Label>
                  ))}
                </RadioGroup>
                {method === 'kort' && (
                  <div className="mt-5 grid gap-4 sm:grid-cols-3">
                    <div className="grid gap-2 sm:col-span-3">
                      <Label htmlFor="card">Kortnummer</Label>
                      <Input id="card" inputMode="numeric" placeholder="4242 4242 4242 4242" autoComplete="cc-number" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="exp">Udløb</Label>
                      <Input id="exp" placeholder="MM/ÅÅ" autoComplete="cc-exp" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="cvc">CVC</Label>
                      <Input id="cvc" inputMode="numeric" placeholder="123" autoComplete="cc-csc" />
                    </div>
                  </div>
                )}
                <p className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
                  <Lock className="size-4" aria-hidden /> Demo-betaling – der trækkes ingen penge.
                </p>
              </fieldset>
            </div>

            <aside className="h-fit rounded-lg border bg-card p-6 lg:sticky lg:top-24">
              <h2 className="text-2xl font-semibold">Din ordre</h2>
              <ul className="mt-4 space-y-2 text-sm">
                {cart.lines.map(({ item, quantity }) => (
                  <li key={item.id} className="flex justify-between gap-4">
                    <span>
                      {quantity} × {item.name}
                    </span>
                    <span className="tabular-nums">{formatPrice(item.price * quantity)}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-4 flex items-baseline justify-between border-t pt-4">
                <span className="text-muted-foreground">I alt</span>
                <span className="font-display text-3xl font-semibold">{formatPrice(cart.total)}</span>
              </div>
              <Button type="submit" size="lg" className="mt-6 w-full" disabled={paying}>
                {paying ? <Loader2 className="animate-spin" /> : <Lock />}
                {paying ? 'Behandler betaling…' : `Betal ${formatPrice(cart.total)}`}
              </Button>
            </aside>
          </form>
        )}
      </div>
    </PageShell>
  )
}
