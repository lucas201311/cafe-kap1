import { Link, createFileRoute } from '@tanstack/react-router'
import { CalendarDays, Coffee, CreditCard, Leaf } from 'lucide-react'

import { MenuRow } from '@/components/menu-row'
import { PageShell } from '@/components/site-layout'
import { Button } from '@/components/ui/button'
import { menu } from '@/lib/fixtures'

export const Route = createFileRoute('/')({
  component: Home,
})

const favourites = ['Cappuccino', 'Vanilla Latte', 'Matcha', 'Kanelsnegl']
  .map((name) => menu.find((m) => m.name === name)!)

function Home() {
  return (
    <PageShell>
      <section className="relative isolate overflow-hidden">
        <img
          src="/.netlify/images?url=/img/hero.png&w=1800&fm=webp&q=75"
          alt="En cappuccino med latte art på et træbord i caféen"
          className="absolute inset-0 -z-10 size-full object-cover"
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-espresso/90 via-espresso/60 to-espresso/10" />
        <div className="mx-auto flex min-h-[78vh] max-w-content flex-col justify-center px-4 py-24 text-primary-foreground sm:px-6">
          <p className="text-sm tracking-[0.3em] uppercase opacity-80">Velkommen til</p>
          <h1 className="mt-2 font-script text-7xl font-normal leading-none sm:text-8xl md:text-9xl">
            cafe kap
          </h1>
          <p className="mt-6 max-w-md text-lg text-primary-foreground/85">
            Kaffe, te og hjemmebag. Book et bord, eller bestil og betal direkte
            fra telefonen – vi giver besked, når det er klar.
          </p>
          <div className="mt-10 flex flex-wrap gap-3">
            <Button asChild size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90">
              <Link to="/menu">Bestil fra menuen</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-primary-foreground/40 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
            >
              <Link to="/bestil-bord">Book et bord</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="border-b bg-secondary/40">
        <div className="mx-auto grid max-w-content gap-8 px-4 py-12 sm:px-6 md:grid-cols-3">
          {[
            { icon: Coffee, title: 'Se menuen', text: 'Kaffe, drikke uden kaffe og snacks – alt fra 10 kr.' },
            { icon: CreditCard, title: 'Bestil & betal', text: 'Vælg dine drikke, betal med kort eller MobilePay.' },
            { icon: CalendarDays, title: 'Book bord', text: 'Reservér plads til dig og dine venner på få sekunder.' },
          ].map(({ icon: Icon, title, text }) => (
            <div key={title} className="flex gap-4">
              <div className="grid size-11 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground">
                <Icon className="size-5" aria-hidden />
              </div>
              <div>
                <h2 className="text-2xl font-semibold">{title}</h2>
                <p className="text-muted-foreground">{text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="espresso-texture text-primary-foreground">
        <div className="mx-auto grid max-w-content items-center gap-12 px-4 py-20 sm:px-6 md:grid-cols-2">
          <div>
            <p className="flex items-center gap-2 text-sm tracking-[0.3em] uppercase opacity-70">
              <Leaf className="size-4" aria-hidden /> Husets favoritter
            </p>
            <h2 className="mt-3 text-5xl font-semibold">Det bestiller vores gæster oftest</h2>
            <p className="mt-4 max-w-md text-primary-foreground/70">
              Tryk på plus for at lægge noget i kurven. Du kan bestille til dit
              bord eller som takeaway.
            </p>
            <Button asChild variant="link" className="mt-6 px-0 text-secondary">
              <Link to="/menu">Se hele menuen →</Link>
            </Button>
          </div>
          <ul className="divide-y divide-primary-foreground/10">
            {favourites.map((item) => (
              <MenuRow key={item.id} item={item} />
            ))}
          </ul>
        </div>
      </section>

      <section className="mx-auto grid max-w-content items-center gap-10 px-4 py-20 sm:px-6 md:grid-cols-2">
        <img
          src="/.netlify/images?url=/img/tables.png&w=1000&fm=webp&q=75"
          alt="Hyggeligt hjørne i caféen med dækkede borde"
          className="aspect-[4/3] w-full rounded-lg object-cover"
          loading="lazy"
        />
        <div>
          <h2 className="text-5xl font-semibold">Et bord til jer?</h2>
          <p className="mt-4 max-w-md text-muted-foreground">
            Book et bord til op til 8 personer. Vi bekræfter din reservation,
            så snart personalet har set den.
          </p>
          <Button asChild size="lg" className="mt-8">
            <Link to="/bestil-bord">Book bord</Link>
          </Button>
        </div>
      </section>
    </PageShell>
  )
}
