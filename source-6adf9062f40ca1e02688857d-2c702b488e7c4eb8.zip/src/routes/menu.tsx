import { createFileRoute } from '@tanstack/react-router'
import { ShoppingBag } from 'lucide-react'

import { MenuRow } from '@/components/menu-row'
import { PageShell } from '@/components/site-layout'
import { Button } from '@/components/ui/button'
import { useCart } from '@/lib/cart'
import { categories, formatPrice, menu } from '@/lib/fixtures'

export const Route = createFileRoute('/menu')({
  head: () => ({ meta: [{ title: 'Menu – Cafe Kap' }] }),
  component: MenuPage,
})

function MenuPage() {
  const cart = useCart()
  return (
    <PageShell>
      <section className="bg-secondary/60 py-14 text-center">
        <h1 className="text-6xl font-semibold tracking-[0.15em] uppercase">Menu</h1>
        <p className="font-script text-4xl">cafe kap</p>
        <nav aria-label="Kategorier" className="mt-6 flex justify-center gap-2 px-4">
          {categories.map((c) => (
            <a
              key={c.id}
              href={`#${c.id}`}
              className="rounded-full border border-primary/20 px-4 py-1.5 text-sm transition-colors hover:bg-primary hover:text-primary-foreground motion-reduce:transition-none"
            >
              {c.title}
            </a>
          ))}
        </nav>
      </section>

      <section className="espresso-texture text-primary-foreground">
        <div className="mx-auto grid max-w-content gap-x-16 gap-y-14 px-4 py-16 sm:px-6 lg:grid-cols-2">
          {categories.map((c) => (
            <div
              key={c.id}
              id={c.id}
              className={`scroll-mt-24 ${c.id === 'snacks' ? 'lg:col-start-2' : ''}`}
            >
              <h2 className="flex items-center gap-3 text-3xl font-semibold tracking-[0.12em] uppercase">
                <span aria-hidden className="h-6 w-3 bg-secondary" />
                {c.title}
              </h2>
              <p className="mt-1 text-sm text-primary-foreground/60">{c.subtitle}</p>
              <ul className="mt-4 divide-y divide-primary-foreground/10">
                {menu
                  .filter((m) => m.category === c.id)
                  .map((item) => (
                    <MenuRow key={item.id} item={item} />
                  ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {cart.count > 0 && (
        <div className="sticky bottom-4 z-30 mx-auto -mt-20 mb-4 flex max-w-content justify-end px-4 sm:px-6">
          <Button size="lg" className="shadow-lg" onClick={() => cart.setOpen(true)}>
            <ShoppingBag />
            {cart.count} varer · {formatPrice(cart.total)}
          </Button>
        </div>
      )}
    </PageShell>
  )
}
