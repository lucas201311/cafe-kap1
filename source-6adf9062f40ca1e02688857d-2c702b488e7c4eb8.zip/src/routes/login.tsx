import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { LockKeyhole } from 'lucide-react'
import * as React from 'react'

import { Logo } from '@/components/site-layout'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { demoStaff, staffSignIn } from '@/lib/fixtures'

export const Route = createFileRoute('/login')({
  head: () => ({ meta: [{ title: 'Personale login – Cafe Kap' }] }),
  component: LoginPage,
})

function LoginPage() {
  const navigate = useNavigate()
  const [email, setEmail] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [error, setError] = React.useState('')

  function submit(e: React.FormEvent) {
    e.preventDefault()
    if (staffSignIn(email, password)) navigate({ to: '/personale' })
    else setError('Forkert e-mail eller adgangskode.')
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="espresso-texture hidden flex-col justify-between p-12 text-primary-foreground lg:flex">
        <Logo />
        <div>
          <p className="font-display text-5xl font-semibold leading-tight">
            Hold styr på bestillinger og bookinger – ét sted.
          </p>
          <p className="mt-4 text-primary-foreground/70">Kun for personale hos Cafe Kap.</p>
        </div>
      </div>
      <div className="flex items-center justify-center px-4 py-16">
        <form onSubmit={submit} className="w-full max-w-sm space-y-6">
          <div className="lg:hidden">
            <Logo />
          </div>
          <div>
            <LockKeyhole className="size-8 text-primary" aria-hidden />
            <h1 className="mt-3 text-4xl font-semibold">Personale login</h1>
            <p className="mt-1 text-muted-foreground">Log ind for at se bestillinger.</p>
          </div>
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <div className="grid gap-2">
            <Label htmlFor="email">E-mail</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="password">Adgangskode</Label>
            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
          </div>
          <Button type="submit" size="lg" className="w-full">Log ind</Button>
          <p className="rounded-md bg-muted p-3 text-xs text-muted-foreground">
            Demo-login: <span className="font-medium">{demoStaff.email}</span> /{' '}
            <span className="font-medium">{demoStaff.password}</span>
          </p>
        </form>
      </div>
    </div>
  )
}
