// Demo data for Cafe Kap.
// Everything the app reads or writes goes through this module, so a later
// milestone can swap these functions for real database calls without
// touching the screens. Orders and bookings made on the site are kept in
// localStorage so the staff screen shows them during a demo.

export type MenuCategory = 'med-kaffe' | 'uden-kaffe' | 'snacks'

export type MenuItem = {
  id: string
  name: string
  price: number
  category: MenuCategory
  description: string
}

export const categories: Array<{
  id: MenuCategory
  title: string
  subtitle: string
}> = [
  { id: 'med-kaffe', title: 'Med kaffe', subtitle: 'Kaffe fra vores espressomaskine' },
  { id: 'uden-kaffe', title: 'Uden kaffe', subtitle: 'Te, kakao, juice og smoothies' },
  { id: 'snacks', title: 'Snacks', subtitle: 'Lidt at spise til' },
]

const item = (
  category: MenuCategory,
  name: string,
  price: number,
  description: string,
): MenuItem => ({
  id: `${category}-${name.toLowerCase().replace(/[^a-z0-9æøå]+/g, '-')}`,
  name,
  price,
  category,
  description,
})

export const menu: MenuItem[] = [
  item('med-kaffe', 'Espresso', 10, 'En kort, kraftig shot'),
  item('med-kaffe', 'Americano', 20, 'Espresso toppet op med varmt vand'),
  item('med-kaffe', 'Cappuccino', 10, 'Espresso med skummet mælk'),
  item('med-kaffe', 'Vanilla Latte', 20, 'Latte med vaniljesirup'),
  item('med-kaffe', 'Mocca', 10, 'Espresso, chokolade og mælk'),
  item('med-kaffe', 'Flat White', 10, 'Dobbelt espresso med silkeblød mælk'),
  item('med-kaffe', 'Macchiato', 20, 'Espresso med en klat mælkeskum'),
  item('med-kaffe', 'Drip Coffee', 10, 'Klassisk filterkaffe'),
  item('med-kaffe', 'Cafe Latte', 10, 'Espresso med masser af varm mælk'),
  item('med-kaffe', 'Almond Mocha', 10, 'Mocha med mandelsmag'),
  item('uden-kaffe', 'Taro', 10, 'Cremet taro-latte'),
  item('uden-kaffe', 'Red Velvet', 20, 'Varm red velvet-drik'),
  item('uden-kaffe', 'Hasselnød', 10, 'Varm mælk med hasselnød'),
  item('uden-kaffe', 'Grøn Te', 20, 'Mild grøn te'),
  item('uden-kaffe', 'Matcha', 10, 'Matcha med mælk'),
  item('uden-kaffe', 'Varm kakao', 20, 'Med eller uden flødeskum'),
  item('uden-kaffe', 'Appelsinjuice', 10, 'Kold appelsinjuice'),
  item('uden-kaffe', 'Lemonade', 20, 'Hjemmelavet lemonade'),
  item('uden-kaffe', 'Frugtsmoothie', 10, 'Blandede frugter og bær'),
  item('uden-kaffe', 'Thai Te', 20, 'Sød thai iste med mælk'),
  item('uden-kaffe', 'Æblejuice', 10, 'Kold æblejuice'),
  item('snacks', 'Muffin', 20, 'Dagens muffin'),
  item('snacks', 'Fritter', 10, 'Sprøde fritter'),
  item('snacks', 'Mix tallerken', 10, 'Lidt af det hele'),
  item('snacks', 'Sandwich', 20, 'Frisklavet sandwich'),
  item('snacks', 'Somay', 20, 'Dampede dumplings med peanutsauce'),
  item('snacks', 'Kanelsnegl', 10, 'Bagt hver morgen'),
]

export const formatPrice = (kr: number) => `${kr} kr.`

export const openingHours = [
  { days: 'Mandag – torsdag', hours: '09:00 – 21:30' },
  { days: 'Fredag – søndag', hours: '09:00 – 22:00' },
]

export const bookingTimes = [
  '10:00', '10:30', '11:00', '11:30', '12:00', '12:30', '13:00', '13:30',
  '14:00', '14:30', '15:00', '15:30', '16:00',
]

// --- Orders ---------------------------------------------------------------

export type OrderStatus = 'ny' | 'i-gang' | 'klar' | 'leveret'

export const orderStatuses: Array<{ id: OrderStatus; label: string }> = [
  { id: 'ny', label: 'Ny' },
  { id: 'i-gang', label: 'I gang' },
  { id: 'klar', label: 'Klar' },
  { id: 'leveret', label: 'Leveret' },
]

export type OrderLine = { itemId: string; name: string; price: number; quantity: number }

export type Order = {
  id: string
  customerName: string
  table: string
  note: string
  lines: OrderLine[]
  total: number
  paymentMethod: 'kort' | 'mobilepay'
  paid: boolean
  status: OrderStatus
  createdAt: string
}

export type Booking = {
  id: string
  name: string
  phone: string
  email: string
  guests: number
  date: string
  time: string
  note: string
  status: 'afventer' | 'bekraeftet' | 'ankommet' | 'aflyst'
  createdAt: string
}

export const bookingStatuses: Array<{ id: Booking['status']; label: string }> = [
  { id: 'afventer', label: 'Afventer' },
  { id: 'bekraeftet', label: 'Bekræftet' },
  { id: 'ankommet', label: 'Ankommet' },
  { id: 'aflyst', label: 'Aflyst' },
]

const minutesAgo = (m: number) => new Date(Date.now() - m * 60_000).toISOString()
const today = () => new Date().toISOString().slice(0, 10)

const line = (name: string, quantity: number): OrderLine => {
  const m = menu.find((i) => i.name === name)!
  return { itemId: m.id, name: m.name, price: m.price, quantity }
}

const sumLines = (lines: OrderLine[]) =>
  lines.reduce((sum, l) => sum + l.price * l.quantity, 0)

function seedOrders(): Order[] {
  const seeds: Array<Omit<Order, 'total'>> = [
    { id: '1042', customerName: 'Sofie', table: '4', note: '', lines: [line('Cappuccino', 2), line('Kanelsnegl', 2)], paymentMethod: 'mobilepay', paid: true, status: 'ny', createdAt: minutesAgo(2) },
    { id: '1041', customerName: 'Ahmed', table: 'Takeaway', note: 'Havremælk tak', lines: [line('Vanilla Latte', 1)], paymentMethod: 'kort', paid: true, status: 'i-gang', createdAt: minutesAgo(6) },
    { id: '1040', customerName: 'Maja', table: '2', note: '', lines: [line('Matcha', 1), line('Thai Te', 1), line('Somay', 1)], paymentMethod: 'kort', paid: true, status: 'klar', createdAt: minutesAgo(11) },
    { id: '1039', customerName: 'Jonas', table: '7', note: '', lines: [line('Americano', 1), line('Sandwich', 1)], paymentMethod: 'mobilepay', paid: true, status: 'leveret', createdAt: minutesAgo(24) },
  ]
  return seeds.map((o) => ({ ...o, total: sumLines(o.lines) }))
}

function seedBookings(): Booking[] {
  return [
    { id: 'B-208', name: 'Line Hansen', phone: '22 33 44 55', email: 'line@example.dk', guests: 4, date: today(), time: '14:00', note: 'Fødselsdag', status: 'bekraeftet', createdAt: minutesAgo(180) },
    { id: 'B-209', name: 'Mikkel Berg', phone: '40 11 22 33', email: 'mikkel@example.dk', guests: 2, date: today(), time: '15:30', note: '', status: 'afventer', createdAt: minutesAgo(45) },
    { id: 'B-210', name: 'Emma Larsen', phone: '30 99 88 77', email: 'emma@example.dk', guests: 6, date: today(), time: '12:00', note: 'Barnestol', status: 'ankommet', createdAt: minutesAgo(300) },
  ]
}

// --- Demo store (browser only) -------------------------------------------

const ORDERS_KEY = 'cafekap:orders'
const BOOKINGS_KEY = 'cafekap:bookings'

function read<T>(key: string, seed: () => T[]): T[] {
  const raw = localStorage.getItem(key)
  if (raw) {
    try {
      return JSON.parse(raw) as T[]
    } catch {
      // fall through and reseed
    }
  }
  const seeded = seed()
  localStorage.setItem(key, JSON.stringify(seeded))
  return seeded
}

function write<T>(key: string, value: T[]) {
  localStorage.setItem(key, JSON.stringify(value))
}

export function listOrders(): Order[] {
  return read(ORDERS_KEY, seedOrders)
}

export function createOrder(
  input: Omit<Order, 'id' | 'total' | 'paid' | 'status' | 'createdAt'>,
): Order {
  const orders = listOrders()
  const nextId = String(Math.max(1000, ...orders.map((o) => Number(o.id) || 0)) + 1)
  const order: Order = {
    ...input,
    id: nextId,
    total: sumLines(input.lines),
    paid: true,
    status: 'ny',
    createdAt: new Date().toISOString(),
  }
  write(ORDERS_KEY, [order, ...orders])
  return order
}

export function updateOrderStatus(id: string, status: OrderStatus): Order[] {
  const orders = listOrders().map((o) => (o.id === id ? { ...o, status } : o))
  write(ORDERS_KEY, orders)
  return orders
}

export function listBookings(): Booking[] {
  return read(BOOKINGS_KEY, seedBookings)
}

export function createBooking(
  input: Omit<Booking, 'id' | 'status' | 'createdAt'>,
): Booking {
  const bookings = listBookings()
  const max = Math.max(200, ...bookings.map((b) => Number(b.id.slice(2)) || 0))
  const booking: Booking = {
    ...input,
    id: `B-${max + 1}`,
    status: 'afventer',
    createdAt: new Date().toISOString(),
  }
  write(BOOKINGS_KEY, [booking, ...bookings])
  return booking
}

export function updateBookingStatus(id: string, status: Booking['status']): Booking[] {
  const bookings = listBookings().map((b) => (b.id === id ? { ...b, status } : b))
  write(BOOKINGS_KEY, bookings)
  return bookings
}

// --- Staff login (demo) ---------------------------------------------------

const STAFF_KEY = 'cafekap:staff'
export const demoStaff = { email: 'personale@cafekap.dk', password: 'kaffe123' }

export function staffSignIn(email: string, password: string): boolean {
  const ok =
    email.trim().toLowerCase() === demoStaff.email && password === demoStaff.password
  if (ok) sessionStorage.setItem(STAFF_KEY, email.trim().toLowerCase())
  return ok
}

export function currentStaff(): string | null {
  return sessionStorage.getItem(STAFF_KEY)
}

export function staffSignOut() {
  sessionStorage.removeItem(STAFF_KEY)
}
