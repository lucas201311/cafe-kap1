import * as React from 'react'

import { menu, type MenuItem } from '@/lib/fixtures'

type CartLine = { item: MenuItem; quantity: number }

type CartContextValue = {
  lines: CartLine[]
  count: number
  total: number
  open: boolean
  setOpen: (open: boolean) => void
  add: (item: MenuItem) => void
  setQuantity: (itemId: string, quantity: number) => void
  clear: () => void
}

const CartContext = React.createContext<CartContextValue | null>(null)
const CART_KEY = 'cafekap:cart'

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [quantities, setQuantities] = React.useState<Record<string, number>>({})
  const [open, setOpen] = React.useState(false)
  const [loaded, setLoaded] = React.useState(false)

  React.useEffect(() => {
    try {
      const raw = localStorage.getItem(CART_KEY)
      if (raw) setQuantities(JSON.parse(raw))
    } catch {
      // ignore a corrupt cart
    }
    setLoaded(true)
  }, [])

  React.useEffect(() => {
    if (loaded) localStorage.setItem(CART_KEY, JSON.stringify(quantities))
  }, [quantities, loaded])

  const value = React.useMemo<CartContextValue>(() => {
    const lines = Object.entries(quantities)
      .map(([id, quantity]) => ({ item: menu.find((m) => m.id === id), quantity }))
      .filter((l): l is CartLine => Boolean(l.item) && l.quantity > 0)
    return {
      lines,
      count: lines.reduce((n, l) => n + l.quantity, 0),
      total: lines.reduce((n, l) => n + l.quantity * l.item.price, 0),
      open,
      setOpen,
      add: (item) =>
        setQuantities((q) => ({ ...q, [item.id]: (q[item.id] ?? 0) + 1 })),
      setQuantity: (itemId, quantity) =>
        setQuantities((q) => {
          const next = { ...q }
          if (quantity <= 0) delete next[itemId]
          else next[itemId] = quantity
          return next
        }),
      clear: () => setQuantities({}),
    }
  }, [quantities, open])

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export function useCart() {
  const ctx = React.useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used inside CartProvider')
  return ctx
}
