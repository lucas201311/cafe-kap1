import { Link } from '@tanstack/react-router'
import { Coffee, Menu as MenuIcon, Minus, Plus, ShoppingBag } from 'lucide-react'

import { Button } from '@/components/ui/button'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { useCart } from '@/lib/cart'
import { formatPrice, openingHours } from '@/lib/fixtures'

const nav = [
  { to: '/menu', label: 'Menu' },
  { to: '/bestil-bord', label: 'Book bord' },
  { to: '/personale', label: 'Personale' },
] as const

export function Logo({ className = '' }: { className?: string }) {
  return (
    <Link to="/" className={`flex items-center gap-2 ${className}`}>
      <Coffee className="size-5" aria-hidden />
      <span className="font-script text-3xl leading-none">cafe kap</span>
    </Link>
  )
}

export function SiteHeader() {
  const cart = useCart()
  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-content items-center justify-between px-4 sm:px-6">
        <Logo />
        <nav className="hidden items-center gap-8 text-sm tracking-wide uppercase md:flex">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="text-muted-foreground transition-colors hover:text-foreground motion-reduce:transition-none"
              activeProps={{ className: 'text-foreground' }}
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => cart.setOpen(true)}
            aria-label={`Kurv, ${cart.count} varer`}
          >
            <ShoppingBag />
            <span>{cart.count}</span>
          </Button>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon-sm" className="md:hidden" aria-label="Åbn menu">
                <MenuIcon />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <SheetHeader>
                <SheetTitle className="font-script text-3xl font-normal">cafe kap</SheetTitle>
                <SheetDescription>Navigation</SheetDescription>
              </SheetHeader>
              <nav className="flex flex-col gap-1 px-4">
                {nav.map((n) => (
                  <Link key={n.to} to={n.to} className="rounded-md px-3 py-2 text-lg hover:bg-muted">
                    {n.label}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
      <CartSheet />
    </header>
  )
}

function CartSheet() {
  const cart = useCart()
  return (
    <Sheet open={cart.open} onOpenChange={cart.setOpen}>
      <SheetContent side="right" className="flex flex-col">
        <SheetHeader>
          <SheetTitle className="font-display text-2xl">Din bestilling</SheetTitle>
          <SheetDescription>
            {cart.count === 0 ? 'Kurven er tom.' : `${cart.count} varer i kurven`}
          </SheetDescription>
        </SheetHeader>
        <div className="flex-1 overflow-y-auto px-4">
          {cart.lines.length === 0 ? (
            <div className="flex flex-col items-center gap-4 py-16 text-center text-muted-foreground">
              <Coffee className="size-10" aria-hidden />
              <p>Find noget lækkert på menuen.</p>
              <Button asChild variant="outline" onClick={() => cart.setOpen(false)}>
                <Link to="/menu">Se menuen</Link>
              </Button>
            </div>
          ) : (
            <ul className="divide-y">
              {cart.lines.map(({ item, quantity }) => (
                <li key={item.id} className="flex items-center justify-between gap-3 py-3">
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-sm text-muted-foreground">{formatPrice(item.price)}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon-xs"
                      aria-label={`Fjern én ${item.name}`}
                      onClick={() => cart.setQuantity(item.id, quantity - 1)}
                    >
                      <Minus />
                    </Button>
                    <span className="w-5 text-center tabular-nums">{quantity}</span>
                    <Button
                      variant="outline"
                      size="icon-xs"
                      aria-label={`Tilføj én ${item.name}`}
                      onClick={() => cart.setQuantity(item.id, quantity + 1)}
                    >
                      <Plus />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
        {cart.lines.length > 0 && (
          <SheetFooter className="border-t">
            <div className="flex items-baseline justify-between">
              <span className="text-muted-foreground">I alt</span>
              <span className="font-display text-2xl font-semibold">{formatPrice(cart.total)}</span>
            </div>
            <Button asChild size="lg" onClick={() => cart.setOpen(false)}>
              <Link to="/kasse">Gå til betaling</Link>
            </Button>
          </SheetFooter>
        )}
      </SheetContent>
    </Sheet>
  )
}

export function SiteFooter() {
  return (
    <footer className="espresso-texture text-primary-foreground">
      <div className="mx-auto grid max-w-content gap-10 px-4 py-14 sm:px-6 md:grid-cols-3">
        <div>
          <p className="font-script text-4xl">cafe kap</p>
          <p className="mt-3 max-w-xs text-sm text-primary-foreground/70">
            Kaffe, te og hjemmebag – serveret med ro i maven.
          </p>
        </div>
        <div>
          <h2 className="text-sm tracking-[0.2em] uppercase">Åbningstider</h2>
          <ul className="mt-4 space-y-1 text-sm text-primary-foreground/80">
            {openingHours.map((o) => (
              <li key={o.days} className="flex justify-between gap-4 max-w-xs">
                <span>{o.days}</span>
                <span className="tabular-nums">{o.hours}</span>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="text-sm tracking-[0.2em] uppercase">Find os</h2>
          <p className="mt-4 text-sm text-primary-foreground/80">
            Kaffegade 12
            <br />
            8000 Aarhus C
            <br />
            hej@cafekap.dk
          </p>
        </div>
      </div>
    </footer>
  )
}

export function PageShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">{children}</main>
      <SiteFooter />
    </div>
  )
}
