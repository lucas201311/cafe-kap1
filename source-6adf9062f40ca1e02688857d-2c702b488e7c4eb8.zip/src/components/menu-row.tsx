import { Plus } from 'lucide-react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { useCart } from '@/lib/cart'
import { formatPrice, type MenuItem } from '@/lib/fixtures'

export function MenuRow({ item }: { item: MenuItem }) {
  const cart = useCart()
  const inCart = cart.lines.find((l) => l.item.id === item.id)?.quantity ?? 0
  return (
    <li className="group flex items-center gap-4 py-3">
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline gap-2">
          <span className="text-lg">{item.name}</span>
          <span
            aria-hidden
            className="flex-1 translate-y-[-4px] border-b border-dotted border-current opacity-25"
          />
          <span className="tabular-nums">{formatPrice(item.price)}</span>
        </div>
        <p className="text-sm opacity-60">{item.description}</p>
      </div>
      <Button
        size="icon-sm"
        variant="outline"
        className="relative shrink-0 bg-transparent"
        aria-label={`Læg ${item.name} i kurven`}
        onClick={() => {
          cart.add(item)
          toast.success(`${item.name} er lagt i kurven`, {
            action: { label: 'Se kurv', onClick: () => cart.setOpen(true) },
          })
        }}
      >
        <Plus />
        {inCart > 0 && (
          <span className="absolute -top-2 -right-2 grid size-5 place-items-center rounded-full bg-secondary text-[10px] font-semibold text-secondary-foreground">
            {inCart}
          </span>
        )}
      </Button>
    </li>
  )
}
